# vision_opencv

Packages for interfacing ROS with OpenCV, a library of programming functions for real time computer vision.

---

## Yujie

```shell
git clone https://github.com/ros-perception/vision_opencv.git
git checkout melodic
```
then change the `CMakeLists.txt` by setting specfic version, such as `find_package(OpenCV 3.4 REQUIRED`
