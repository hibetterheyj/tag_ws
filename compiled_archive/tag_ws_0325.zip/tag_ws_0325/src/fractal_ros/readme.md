# fractal_ros

## TODO

- rewrite as OOP
- update pose and publish to tf
- update the drawing code
- update the msg code

